package com.avensys.logindemo.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.avensys.logindemo.model.Users;
import com.avensys.logindemo.repositories.UserRepo;


@Service
public class UserService {
    @Autowired
    private UserRepo ur;
    @Autowired
    private PasswordEncoder pe;

    public String addUser(Users user){
        user.setPassword(pe.encode(user.getPassword()));
        ur.save(user);
        return "User Added";
    }
    
}
