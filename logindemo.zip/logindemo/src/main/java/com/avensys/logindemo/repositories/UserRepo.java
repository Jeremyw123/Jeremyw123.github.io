package com.avensys.logindemo.repositories;

import java.util.Optional;

import org.springframework.data.repository.ListCrudRepository;

import com.avensys.logindemo.model.Users;


public interface UserRepo extends ListCrudRepository<Users, Integer> {
    Optional<Users> findByName(String name);
}
