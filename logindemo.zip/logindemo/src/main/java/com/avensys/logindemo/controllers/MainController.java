package com.avensys.logindemo.controllers;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {
    @GetMapping("/") 
    @PreAuthorize("hasAuthority('ROLE_ADMIN') or hasAuthority('ROLE_MANAGER')")
    public String showMain(){
        return "home";
    }
    @GetMapping("/manager") 
    @PreAuthorize("hasAuthority('ROLE_MANAGER')")
    public String showlink(){
        return "manager";
    }
}
